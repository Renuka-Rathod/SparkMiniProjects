#!/usr/bin/python

#Entrypoint 2.x
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()

# On yarn:
# spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().master("yarn").getOrCreate()
# specify .master("yarn")

sc = spark.sparkContext

rdd=sc.textFile("file:///home/talentum/test-jupyter/spark1/whitehouse_visits.txt").map(lambda line:line.split(','))\
.filter(lambda pot: pot[19]=='POTUS')\
.map(lambda col: (col[0],col[1],col[6],col[11],col[21],col[25]))
print(rdd.take(5))
