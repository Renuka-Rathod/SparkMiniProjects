#!/usr/bin/python

from pyspark.sql import SparkSession
from pyspark.sql.functions import max

# Initialize Spark session
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()

# Read the CSV file into a DataFrame
df = spark.read.csv("file:///home/talentum/test-jupyter/spark4/Electric_Vehicle_Population_Data_LabExam.csv", header=True, inferSchema=True)
df.show(1)

print(df.columns)
df.printSchema()

# 1. Find the City with most number of “Battery Electric Vehicle (BEV)”
df.select('Electric Vehicle Type').distinct().show()

dfbattery = df.filter(df["Electric Vehicle Type"] == "Battery Electric Vehicle (BEV)")

# Group by "City" and count occurrences
dfBatteryCount = dfbattery.groupBy("City").count()

# Show the results
dfBatteryCount.orderBy('count', ascending=False).show(1)

# Describe the DataFrame
df.describe().show()

# Filter out rows with null City values
df_notnull = df.filter(df.City.isNotNull())

# Group by City and count
df_City = df_notnull.groupBy('City').count().orderBy('count', ascending=False)
df_City.show(1)

# SQL query to find the city with the most vehicles
df_notnull.createOrReplaceTempView('citytable')
query = '''SELECT City, COUNT(*) AS total FROM citytable GROUP BY City ORDER BY total DESC LIMIT 1'''
cityresult = spark.sql(query)
cityresult.show()

# Find the model with the maximum electric range
df.createOrReplaceTempView('electricRange')
query = '''SELECT Make, Model, Electric_Range FROM electricRange ORDER BY Electric_Range DESC LIMIT 1'''
spark.sql(query).show()

# Filter by postal code 98126
area = df.filter(df.Postal_Code == 98126).select('Make', 'Model', 'Postal_Code')
area.show()

# Query to find the most brought vehicle in postal code 98126
query = '''SELECT Model, Make, COUNT(*) AS mostBrought FROM electricRange WHERE Postal_Code = 98126 GROUP BY Model, Make'''
spark.sql(query).show()

# Find the model year with most CAFV_Eligibility as "Not eligible due to low battery range"
cafv = df.filter(df.CAFV_Eligibility == "Not eligible due to low battery range").groupBy('Model Year').count().orderBy('count', ascending=False)
cafv.show(1)

# Filter TESLA Model S and order by Electric_Range
tesla = df.filter((df.Make == "TESLA") & (df.Model == "MODEL S")).orderBy('Electric_Range', ascending=False)
tesla.select('Make', 'Model', 'Electric_Range').show(1)

# Write DataFrame to Hive table
hivetable = df.withColumnRenamed('Electric Vehicle Type', 'Electric_type').select('County', 'City', 'State', 'Make', 'Model', 'Electric_type')
hivetable.write.mode("overwrite").partitionBy('State', 'City', 'County').saveAsTable('EVMS_US')

